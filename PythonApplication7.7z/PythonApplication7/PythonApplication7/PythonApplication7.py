num1 = input("Введите число: ")
string = num1
print (num1)


def is_alive(health):
    if health <= 0:
        print ("False")
    else:
        print ("True")
is_alive (0)
is_alive (10)
is_alive(-100)
